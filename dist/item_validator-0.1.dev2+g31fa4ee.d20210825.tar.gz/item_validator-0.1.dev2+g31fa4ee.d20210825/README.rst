==========================
Item Description Validator
==========================


.. image:: https://img.shields.io/pypi/v/item_validator.svg
        :target: https://pypi.python.org/pypi/item_validator

.. image:: https://img.shields.io/travis/Mahir-Sparkess/item_validator.svg
        :target: https://travis-ci.com/Mahir-Sparkess/item_validator

.. image:: https://readthedocs.org/projects/item-validator/badge/?version=latest
        :target: https://item-validator.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




Item Description schema to validate proper usage and identify and mistakes with a schema validator


* Free software: BSD - see LICENSE file in top-level package directory
* Documentation: https://item-validator.readthedocs.io.


Features
--------

Item Description Validator -
Uses Cerberus to create Schemas to validate .yml items to assert whether or not item is of valid format.

Installation
------------

Find the 'tar.gz' zip of the package and pip install it:

.. code-block::
    pip install tar.gz

d



Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
