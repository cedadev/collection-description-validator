=====
Usage
=====

To use Item Description Validator in a project::

    import item_validator
