=======
History
=======

0.1.0 (2021-08-23)
------------------

* First release on PyPI.
